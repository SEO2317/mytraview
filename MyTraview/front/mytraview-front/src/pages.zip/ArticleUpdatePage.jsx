import { useAtom } from 'jotai'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import curBoardAtom from '../components/atoms/curBoardAtom'

const ArticleUpdatePage = () => {

    const [articleId, setArticleId] = useState("")
    const [title, setTitle] = useState("")
    const [content, setContent] = useState("")
    const [curBoard, setCurBoard] = useAtom(curBoardAtom);

    const handleModify = () => {

        if (title === "" || content === "") {
            alert("제목 및 내용을 입력해주세요.")

        } else {

            let headers = new Headers({
                "Content-Type": "application/json",
            })

            const accessToken = sessionStorage.getItem("ACCESS_TOKEN")
            if (accessToken && accessToken !== null) {
                headers.append("Authorization", "Bearer " + accessToken);
            }

            const req = {
                articleId: curBoard,
                title: title,
                content: content,
            }
            console.log(req);
            console.log("글 수정을 위한 엑세스 토큰 확인: " + accessToken);
            const options = {
                method: 'PUT',
                headers: headers,
                body: JSON.stringify(req)
            };

            fetch('http://localhost:3100/article', options)
                .then(response => {
                    response.json();
                    if (response.ok) { alert("수정이 완료되었습니다.") } else {
                        alert("해당 요청은 작성자만 가능합니다.")
                    }
                    
                })
                .catch(error => console.error('해당 요청은 작성자만 가능합니다.', error));
            console.log("handleModify clicked button")
        }
    }

    const handleDelete = () => {

        let headers = new Headers({
            "Content-Type": "application/json",
        })

        const accessToken = sessionStorage.getItem("ACCESS_TOKEN")
        if (accessToken && accessToken !== null) {
            headers.append("Authorization", "Bearer " + accessToken);
        }

        const req = {
            articleId: curBoard,
            title,
            content
        }

        console.log(req);
        console.log(curBoard);
        const options = {
            method: 'DELETE',
            headers: headers,
            body: JSON.stringify(req)
        };

        fetch(`http://localhost:3100/article/articleId=${articleId}`, options)
            .then(response => {
                if (response.ok) { alert("삭제가 완료되었습니다.") } else { alert("해당 요청은 작성자만 가능합니다.") }
            })
            .catch(response => response.resMessage);
        console.log("handledelete clicked button")
    }

    useEffect(() => {
        fetch(`http://localhost:3100/article/articleId=${articleId}`)
            .then(response => response.json())
            .then(data => {
                console.log("현재 게시글 번호:" + curBoard);
                setArticleId(data.articleId);
                setTitle(data.title);
                setContent(data.content);
            })
            .catch(error => console.error(error))
    }, [])


    return (
        <>
            <form>
                <div className='max-w-2xl px-6 py-10 m-auto bg-white rounded-md'>
                    <Link to="/ArticleListPage" className="mb-6 text-2xl font-bold text-left text-gray-500 border-4">
                        목록으로
                    </Link>
                    <div className="mb-6 text-2xl font-bold text-left text-gray-500 border-4">잡담</div>
                    <div>
                        <div className="mb-10 text-2xl font-bold text-center text-gray-500 border-4">
                            번호<input type="text" readOnly value={curBoard} className="px-30 py-4 text-sm w-full text-center text-gray-900 border-2" />
                        </div>
                    </div>
                    <div>
                        <div className="mb-10 text-2xl font-bold text-center text-gray-500 border-4">
                            제목
                            <input type="text" name="title" value={title} placeholder="고민을 한 마디로 알려주세요" onChange={(event) => setTitle(event.target.value)} className="px-30 py-4 text-sm w-full text-left text-gray-900 border-2" />
                        </div>
                    </div>
                    <div>
                        <div className="items-center w-full h-[400px] text-gray-600 bg-gray-100 rounded-md resize-none mb-9 text-center">
                            내용
                            <textarea type="text" name="content" value={content} placeholder="당신의 고민을 적어보세요" onChange={event => setContent(event.target.value)} className="items-center w-full h-[400px] text-gray-600 bg-gray-100 rounded-md resize-none mb-9 text-center" />
                        </div>
                    </div>
                    <Link to='/ArticleListPage'>
                        <button type='delete' onClick={handleDelete} className='float-right px-5 py-2 font-bold border-2 rounded-lg text-neutral-900 hover:bg-neutral-200'>글 삭제</button>
                    </Link>
                    <Link to='ArticleDetailPage'>
                        <button type='modify' onClick={handleModify} className='float-right px-5 py-2 font-bold border-2 rounded-lg text-neutral-900 hover:bg-neutral-200'>글 수정</button>
                    </Link>

                </div>
            </form>
        </>
    )
}

export default ArticleUpdatePage