import React from 'react'

const empty = () => {
  return (
    <div>empty</div>
  )
}

export default empty